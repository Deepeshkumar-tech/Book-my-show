package com.bookmyshow_db.book_my_show_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
