package com.bookmyshow_db.book_my_show_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyShowDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyShowDbApplication.class, args);
	}

}
