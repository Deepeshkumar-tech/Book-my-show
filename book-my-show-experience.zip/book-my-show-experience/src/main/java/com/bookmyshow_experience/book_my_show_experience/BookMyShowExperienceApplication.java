package com.bookmyshow_experience.book_my_show_experience;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyShowExperienceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyShowExperienceApplication.class, args);
	}

}
