package com.bookmyshow_experience.book_my_show_experience;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowExperienceApplicationTests {

	@Test
	void contextLoads() {
	}

}
