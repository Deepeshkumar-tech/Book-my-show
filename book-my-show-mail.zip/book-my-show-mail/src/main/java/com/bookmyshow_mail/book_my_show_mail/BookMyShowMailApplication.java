package com.bookmyshow_mail.book_my_show_mail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyShowMailApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyShowMailApplication.class, args);
	}

}
