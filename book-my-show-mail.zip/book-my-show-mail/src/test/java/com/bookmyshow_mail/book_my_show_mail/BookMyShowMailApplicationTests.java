package com.bookmyshow_mail.book_my_show_mail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowMailApplicationTests {

	@Test
	void contextLoads() {
	}

}
